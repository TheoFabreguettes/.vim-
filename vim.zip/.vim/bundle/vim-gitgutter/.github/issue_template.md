> What is the latest commit SHA in your installed vim-gitgutter?

> What vim/nvim version are you on?

